package ua.kyiv.app.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ua.kyiv.app.domain.User;
import ua.kyiv.app.service.UserService;
import ua.kyiv.app.service.impl.UserServiceImpl;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserService userService = UserServiceImpl.getUserServiceImpl();

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String login = request.getParameter("login");
		String password = request.getParameter("password");

		User user = userService.getUserByEmail(login);

		if (user != null && user.getPassword().equalsIgnoreCase(password)) {
			request.setAttribute("userName", user.getFirstName());
			request.getRequestDispatcher("cabinet.jsp").forward(request, response);
		}
		else
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
}
