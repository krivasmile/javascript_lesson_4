package ua.kyiv.app.service;

import ua.kyiv.app.domain.Product;
import ua.kyiv.app.shared.AbstractCRUD;

public interface ProductService extends AbstractCRUD<Product> {

}
