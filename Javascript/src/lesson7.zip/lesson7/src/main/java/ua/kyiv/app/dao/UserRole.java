package ua.kyiv.app.dao;

public enum UserRole {
	ADMINISTRATOR, USER
}
