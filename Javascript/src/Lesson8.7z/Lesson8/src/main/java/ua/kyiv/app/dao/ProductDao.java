package ua.kyiv.app.dao;

import ua.kyiv.app.domain.Product;
import ua.kyiv.app.shared.AbstractCRUD;

public interface ProductDao extends AbstractCRUD<Product> {

}
